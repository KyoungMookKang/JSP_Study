package com.multi.Exam;

public class Kitchen {
    public static void main(String[] args) {

        PastaCook cook = new PastaCook();
        cook.doGet();
    }
}
