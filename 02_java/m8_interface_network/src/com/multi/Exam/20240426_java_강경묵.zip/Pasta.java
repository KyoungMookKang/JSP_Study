package com.multi.Exam;

public interface Pasta {
    public void spaghetti();
    public void fettuccine();
    public void penne();
}
