package com.multi.Exam;

public class Exam01 {
    public static void main(String[] args) {
        Exam01_1 a1 = new Exam01_1("자바", "14:30", "강경묵");
        Exam01_1 a2 = new Exam01_1("백엔드", "15:30", "카리나");

        System.out.println(a1);
        System.out.println(a2);

    }
}
