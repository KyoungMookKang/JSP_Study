package com.multi.Exam;

public class Cal4 {
    public int sum(int count , int price){
        return count * price;
    }

    public int div(int sum, int person) {

        return sum / person;
    }

    public int total(int sum, int sum2){
        return sum + sum2;
    }

    public int add(int x, int y){
        return  x+y;
    }



}
