package com.multi.basic.Exam;

public class Exam02 {
    public static void main(String[] args) {
        Double height = 199.9;
        Double weight = (height - 100) * 0.9;

        System.out.println(weight);
    }
}
