package com.multi.basic.Exam;

public class Exam01 {
    public static void main(String[] args) {
        int height = 220;
        int width = 110;

        int sum = height * width;
        System.out.println("사각형의 넓이는 " + sum);

    }
}
