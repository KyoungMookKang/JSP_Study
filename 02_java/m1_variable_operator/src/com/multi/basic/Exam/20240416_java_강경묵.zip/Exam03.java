package com.multi.basic.Exam;

public class Exam03 {
    public static void main(String[] args) {

        String name = "카리나";
        String tel = "010-1111-2222";
        String a = "Skt";

        System.out.println("문자열 연결");

        System.out.println(name + "님은 " + a + "에 "+ tel + " 로 가입되셨습니다." );

    }
    }
