package com.multi.Exam;


public class ImageEx extends Thread {
    @Override
    public void run() {
        String img = "img_007.png";
    }
}