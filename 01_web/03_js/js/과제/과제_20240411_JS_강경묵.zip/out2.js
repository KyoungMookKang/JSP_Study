function add(x, y){
    alert('더하기 기능 처리 후 결과창' + (x + y))
}
function minus(x, y){
    alert('빼기 기능 처리 후 결과창' + (x - y))
}

function go() {
    alert('go함수를 누르셨군요.!')
}
function move() {
    alert('move함수를 누르셨군요.!')
}



function travel() {
    alert('편안한 여행되세요')
}
function rest() {
    alert('편안하게 쉬세요')
}